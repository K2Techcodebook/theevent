<?php $__env->startSection('title'); ?> Upload video <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>
 <link href="//vjs.zencdn.net/4.12/video-js.css" rel="stylesheet">

    <!--==========================
      Contact Section
    ============================-->
    <section id="contact" class="section-bg wow fadeInUp">

      <div class="container">
        <div class="col-lg-10 col-lg-offset-2">
                        <?php if(session('status')): ?>

                                      <div class="alert alert-success">
                                          <?php echo e(session('status')); ?>

                                      </div>
                                  <?php endif; ?>
                                  <?php if(count($errors) > 0): ?>
                                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                          <div class="alert alert-danger"><?php echo e($error); ?></div>

                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                  <?php endif; ?>


                        </div>
        <div class="section-header">
         <h2>Video Upload</h2>
        </div>

          <video id="example_video_1" class="video-js vjs-default-skin vjs-big-play-centered"
                    controls preload="auto" height="600" width="980">

                 <source src="<?php echo e(url('storage/videos/'.$data->filename)); ?>" type="<?php echo e($data->extension); ?>" />
             </video>

      </div>
      </section><!-- #contact -->


     <?php $__env->stopSection(); ?>




     <?php $__env->startSection('footer'); ?>
    <script src="//vjs.zencdn.net/4.12/video.js"></script>
     <script>
      videojs(document.getElementById('example_video_1'), {}, function() {
          // This is functionally the same as the previous example.
      });
  </script>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>