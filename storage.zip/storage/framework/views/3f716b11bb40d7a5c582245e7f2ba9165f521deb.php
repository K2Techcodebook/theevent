<?php echo $__env->make('sitelayout.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div id="app">


            <main class="py-4">
                <?php echo $__env->yieldContent('content'); ?>
               </main>
        </div>
        <?php echo $__env->make('sitelayout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php echo $__env->make('sitelayout.footerscript', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>
    </html>
