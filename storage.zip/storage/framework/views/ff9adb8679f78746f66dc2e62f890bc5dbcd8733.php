<?php $__env->startSection('title'); ?> Upload video <?php $__env->stopSection(); ?>
  <?php $__env->startSection('content'); ?>

<?php

//echo phpinfo();

?>

  <br><br>
  <!--==========================
    Contact Section
  ============================-->
  <section id="contact" class="section-bg wow fadeInUp">

    <div class="container">
      <div class="col-lg-10 col-lg-offset-2">
                      <?php if(session('status')): ?>

                                    <div class="alert alert-success">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(count($errors) > 0): ?>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <div class="alert alert-danger"><?php echo e($error); ?></div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php endif; ?>


                      </div>
      <div class="section-header">
       <h2>Video Upload</h2>
      </div>


      <div class="form">
        <?php echo Form::open(['method' => 'post','class'=>'form-horizontal','url' => 'Update_video','files'=>true]); ?>

        <!-- <form action="<?php echo e(route('Update_video')); ?>" method="post" enctype="multipart/form-data"> -->
<?php echo e(csrf_field()); ?>

<div class="form-group">
<label for="Product Name">Product Name</label>
<input type="text" name="name" class="form-control"  placeholder="Product Name" >
</div>
<label for="Product Name">Product photos (can attach more than one):</label>
<br />
<input type="file" class="form-control" name="video" />
<br /><br />
  <div class="text-center"><button type="submit"><?php echo e(__('Upload')); ?><span class="primary"> Now!</span></button></div>
<!-- </form> -->
<?php echo Form::close(); ?>

      </div>

    </div>
  </section><!-- #contact -->




   <?php $__env->stopSection(); ?>




   <?php $__env->startSection('footer'); ?>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>