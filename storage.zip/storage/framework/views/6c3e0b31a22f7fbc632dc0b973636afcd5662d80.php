<?php $__env->startSection('content'); ?>
<br><br>
<!--==========================
  Contact Section
============================-->
<section id="contact" class="section-bg wow fadeInUp">

  <div class="container">

    <div class="section-header">
     <h2> <?php echo e(__('Login')); ?> to your Account</h2>
    </div>


    <div class="form">
   <form method="POST" action="<?php echo e(route('login')); ?>">
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="Enter your Email here.." required autofocus>
        <?php if($errors->has('email')): ?>
        <span class="invalid-feedback" role="alert">
          <strong><?php echo e($errors->first('email')); ?></strong>
        </span>
        <?php endif; ?>
      </div>
<div class="form-group">
        <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="Enter your password here..." required>
        <?php if($errors->has('password')): ?>
        <span class="invalid-feedback" role="alert">
          <strong><?php echo e($errors->first('password')); ?></strong>
        </span>
        <?php endif; ?>
          </div>
        <!-- CHECKBOX -->
       <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
<!--     <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?> checked> -->
      <label for="remember" class="label-check">
          <span class="checkbox primary primary"><span></span></span>
          Remember username and password
      </label>
        <!-- /CHECKBOX -->
      <p>Forgot your password? <a href="<?php echo e(route('password.request')); ?>" class="primary">Click here!</a></p>
      <button type="submit" class="button mid dark">Login <span class="primary">Now!</span></button>

    </form>
  </div>
</div>
</section><!-- #contact -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>