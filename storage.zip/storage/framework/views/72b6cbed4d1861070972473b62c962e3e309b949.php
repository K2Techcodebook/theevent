<?php $__env->startSection('content'); ?>
<br><br>
<!--==========================
  Contact Section
============================-->
<section id="contact" class="section-bg wow fadeInUp">

  <div class="container">

    <div class="section-header">
     <h2>Registration</h2>
    </div>


    <div class="form">
      <form   method="POST" action="<?php echo e(route('register_new_user')); ?>" aria-label="<?php echo e(__('Register')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-row">
          <div class="form-group col-md-6">
            <input type="text"   class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" placeholder="Enter your Fullname here...">
            <?php if($errors->has('name')): ?>
            <span class="invalid-feedback" role="alert">
                <strong style="color:red"><?php echo e($errors->first('name')); ?></strong>
            </span>
            <br/>
            <br/>
            <?php endif; ?>
          </div>
          <div class="form-group col-md-6">
            <input type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="Enter your email address here...">
            <?php if($errors->has('email')): ?>
            <span class="invalid-feedback" role="alert">
              <strong style="color:red"><?php echo e($errors->first('email')); ?></strong>
            </span>
            <br/>
            <br/>
            <?php endif; ?>
          </div>
        </div>
        <div class="form-group">
          <input type="text"  class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username')); ?>" placeholder="Enter your username here...">

          <?php if($errors->has('username')): ?>
          <span class="invalid-feedback" role="alert">
            <strong style="color:red"><?php echo e($errors->first('username')); ?></strong>
          </span>
          <br/>
          <br/>
          <?php endif; ?>
        </div>
        <div class="form-row">
          <div class="form-group col-md-6">
            <input type="password" name="password"  class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="Enter your password here...">
            <?php if($errors->has('password')): ?>
            <span class="invalid-feedback" role="alert">
            <strong style="color:red"><?php echo e($errors->first('password')); ?></strong>
            </span>
            <br/>
            <br/>
            <?php endif; ?>
          </div>
          <div class="form-group col-md-6">
            <input type="password"  name="password_confirmation" class="form-control" placeholder="Repeat your password here...">
            <div class="validation"></div>
          </div>
        </div>

        <div class="text-center"><button type="submit"><?php echo e(__('Register')); ?><span class="primary">Now!</span></button></div>
      </form>
    </div>

  </div>
</section><!-- #contact -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>