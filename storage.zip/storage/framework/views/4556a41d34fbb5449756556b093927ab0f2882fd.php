<?php echo $__env->make('sitelayout.header0', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

       <?php echo $__env->yieldContent('content'); ?>

         <?php echo $__env->yieldContent('footer'); ?>


  <?php echo $__env->make('sitelayout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('sitelayout.footerscript', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
