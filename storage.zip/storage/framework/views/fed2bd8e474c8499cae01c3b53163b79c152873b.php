<!-- Scripts -->
<script src="<?php echo e(asset('js/all.js')); ?>" defer></script>
